import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='maperalta',
    application_name='crud-serverless-users',
    app_uid='1CBCD5VTpW9qg17wj7',
    org_uid='085923f4-a67d-4207-b3d4-d93d71efc0bf',
    deployment_uid='1b07a0e8-9e86-4a19-8383-c53df0b75a07',
    service_name='crud-serverless-users',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='7.2.0',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'crud-serverless-users-dev-delete-users', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('deleteUsers/handler.deleteUsers')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
