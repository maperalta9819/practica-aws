
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'maperalta',
  applicationName: 'crud-serverless-users',
  appUid: '1CBCD5VTpW9qg17wj7',
  orgUid: '085923f4-a67d-4207-b3d4-d93d71efc0bf',
  deploymentUid: '1b07a0e8-9e86-4a19-8383-c53df0b75a07',
  serviceName: 'crud-serverless-users',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '7.2.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'crud-serverless-users-dev-create-users', timeout: 6 };

try {
  const userHandler = require('./createUsers/handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.createUsers, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}